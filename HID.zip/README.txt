This is my implementation of a really simple USB 
Human Device Interface. The functionality is to 
print a message when the button is pressed.
The library added is a made to work with newer Arduino IDE,
not just 1.0, by adding "const" to every PROGMEM declaration.
Also, I have some problems with Windows10 x64 OS. 
